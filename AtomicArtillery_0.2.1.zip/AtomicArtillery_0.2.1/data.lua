--data.lua

require("prototypes.recipe.ammo")
require("prototypes.entity.projectiles")
require("prototypes.item.ammo")
require("prototypes.technology.ammo")
