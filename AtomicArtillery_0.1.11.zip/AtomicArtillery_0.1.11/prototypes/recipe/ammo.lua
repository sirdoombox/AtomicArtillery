data:extend(
{
	{
		type = "recipe",
		name = "atomic-artillery-shell",
		enabled = false,
		energy_required = 120,
		ingredients =
		{
			{"atomic-bomb", 1},
			{"explosive-uranium-cannon-shell", 4},
			{"rocket-control-unit", 3},
			{"radar", 1}
		},
		result = "atomic-artillery-shell"
	}
}
)